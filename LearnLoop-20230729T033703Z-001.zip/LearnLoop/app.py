from flask import Flask, jsonify, render_template, request
from flask_cors import CORS 
import sqlite3 as sql
from artigos import Artigos

app = Flask(__name__)
CORS(app)

@app.route("/")
def homepage():
	return render_template("index.html")
	
@app.route("/feed")
def feedPage():
	with sql.connect("artigos.db") as db:
		cursor = db.cursor()
		cursor.execute("SELECT titulo, texto, autor, fontes, id FROM artigos")
		dados = cursor.fetchall()
	
	artigos = []
	for article in dados:
		artigos.append({
			"titulo": article[0],
			"texto": article[1],
			"autor": article[2],
			"fontes": article[3],
			"id": article[4]
		})
	return render_template("feed.html", artigos=artigos)
	
@app.route("/post/<artigo>")
def artigoPage(artigo):
	
	article = Artigos(artigo, "ok").get_artigo(artigo)
	return render_template("post.html", artigo=article)
	
	
	return render_template("post.html", post=article)
	
@app.route("/api/gerar-resumo", methods=["POST"])
def gerarResumo():
	data = request.get_json()
	
@app.route("/api/gerar-mapa", methods=["POST"])
def gerarMapa():
	data = request.get_json()
	
@app.route("/api/publicar-artigo", methods=["POST"])
def createArtigo():
	data = request.get_json()
	print(data["conteudo"])
	return jsonify({
		"response": Artigos(data["titulo"], data["autor"]).create_artigo(data["titulo"], data["conteudo"], data["fontes"])
	})
	
@app.route("/api/delete-artigo", methods=["POST"])
def deleteArticle():
	data = request.get_json()
	
	return jsonify({
		"response": Artigos(data["artigo"], data["autor"]).apagar_artigo()
	})
	
@app.route("/create")
def createArtigoPage():
	return render_template("create-artigo.html")
	
if __name__ == "__main__":
	app.run(port=7070, host="0.0.0.0", debug=True)