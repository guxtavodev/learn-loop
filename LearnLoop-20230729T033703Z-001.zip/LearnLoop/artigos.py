import sqlite3 as sql 
import uuid
import hashlib

class Artigos():
  def __init__(self, artigo, user):
    self.artigo = artigo 
    self.user = user

  @staticmethod
  def crip(dado):
        # Função para criptografar dados usando SHA-256
        dadoCriptografado = hashlib.sha256(dado.encode()).hexdigest()
        return dadoCriptografado

  def create_artigo(self, title, text, fontes):
    if title == " " or title == None or text == " " or text == None:
      return {
        "msg": "escreva algo"
      }
    id = uuid.uuid4()

    with sql.connect("artigos.db") as db:
      cursor = db.cursor()
      cursor.execute("INSERT INTO artigos (titulo, id, texto, fontes, autor) VALUES (?,?,?,?,?)", (title, str(id), text, fontes, self.user))
      db.commit()
      
    return {
    	"msg": "success",
    	"id": str(id)
    }
  
  def apagar_artigo(self):
  	with sql.connect("artigos.db") as db:
  		cursor = db.cursor()
  		cursor.execute("DELETE FROM artigos WHERE id = ?", (self.artigo))
  		db.commit()
  		
  	with sql.connect("artigos_pub.db") as db:
  		cursor = db.cursor()
  		cursor.execute("DELETE FROM artigos WHERE id = ?", (self.artigo))
  		db.commit()
  		
  	return {
  		"msg": "success"
  	}
  	
  def get_artigo(self, artigo):
  	with sql.connect("artigos.db") as db:
  		cursor = db.cursor()
  		cursor.execute("SELECT titulo, id, fontes, texto, autor FROM artigos WHERE id = ?", (self.artigo,))
  		dados = cursor.fetchall()[0]
  	
  	artigo = {
  		"titulo": dados[0],
  		"texto": dados[3],
  		"fontes": dados[2],
  		"id": dados[1],
  		"autor": dados[4]
  	}
  	
  	return artigo