function createArtigo() {
  var titulo = $("#title").val()
  var disciplina = $("#disciplina").val()
  var conteudo = $("#conteudo").val()
  var fontes = $("#fontes").val()
  
  function convertMarkdown() { 
  var markdownInput = document.getElementById('conteudo').value;
      var converter = new showdown.Converter();
      
      return converter.makeHtml(markdownInput);
   }
  
  axios.post("/api/publicar-artigo", {
    "titulo": titulo,
    "disciplina": disciplina,
    "conteudo": convertMarkdown(),
    "fontes": fontes,
    "autor": localStorage.getItem("user")
  }).then((r) => {
    var msg = r.data.response
    if(msg.msg === "success") {
      alert("Artigo Publicado com sucesso!")
      window.location.href = `/post/${msg.id}`
    } else {
      alert('Algo de errado aconteceu... Tente novamente mais tarde')
    }
  })
}